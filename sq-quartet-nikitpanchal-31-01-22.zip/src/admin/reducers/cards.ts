export default [
  {
    id: 1,
    name: "Luke Skywalker",
    height: 172,
    mass: 77,
    films: 4,
    starships: 2,
    vehicles: 2,
  },
  {
    id: 2,
    name: "R2-D2",
    height: 96,
    mass: 32,
    films: 6,
    starships: 0,
    vehicles: 0,
  },
];
