import React from 'react';
import List from "./List";

export default function Admin() {
    return (
        <List />
    )
}